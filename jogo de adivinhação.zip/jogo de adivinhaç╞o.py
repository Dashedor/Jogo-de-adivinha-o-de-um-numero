import random


def jogo_adivinhacao():
    numero_secreto = random.randint(1, 100)
    tentativas = 0

    print("Bem-vindo ao jogo de adivinhação")
    print("Tente adivinhar o número entre 1 e 100.")

    while True:
        tentativa = int(input("Digite um número: "))
        tentativas += 1

        if tentativa < numero_secreto:
            print("Tenta maior nengue.")
        elif tentativa > numero_secreto:
            print("Tenta mais baixo nengue.")
        else:
            print(f"Acertou o número {numero_secreto} em {tentativas} tentativas!")
            break


if __name__ == "__main__":
    jogo_adivinhacao()